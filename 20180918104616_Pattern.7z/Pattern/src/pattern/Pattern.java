/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pattern;
import java.util.Scanner;
/**
 *
 * @author 1793418
 */
public class Pattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        	Scanner reader = new Scanner(System.in);  
System.out.println("Enter a number: ");
int rows = reader.nextInt(); 
reader.close();
	
        

        for(int i = rows; i >= 1; --i) {
            for(int j = 1; j <= i; ++j) {
                System.out.print("* ");
            }
            System.out.println();
        }
        // TODO code application logic here
    }
    
}
